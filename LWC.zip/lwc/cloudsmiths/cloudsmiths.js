import { LightningElement } from 'lwc';
import submitCloudsmith from '@salesforce/apex/CloudsmithsController.submitCloudsmith';
// importing to show toast notifictions
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class Cloudsmiths extends LightningElement {
    holidayData;
    southAfricaId='';
    isdisabledSearch=true;
    southAfricaRecordDetails;
    errMessage='';
    showLoadingSpinner = false;
    holidayColumns = [
        { label: 'Name', fieldName: 'name' },
        { label: 'Description', fieldName: 'description' },
        { label: 'Type', fieldName: 'type' },
        { label: 'Date', fieldName: 'date', type: 'date' },
    ];
    handleSearchClick(){
         this.showLoadingSpinner = true;
            submitCloudsmith({southAfricaId:this.southAfricaId,gender:this.southAfricaRecordDetails.Gender,citizen:this.southAfricaRecordDetails.Citizen,birthDate:this.southAfricaRecordDetails.BirthDate+''})
            .then(result => {
               
                if(result!=''){
                    var records=JSON.parse(result);
                     console.log("###records",records);
                     if(records.meta.code==200){
                        var holidays=records.response.holidays;
                        var arrOfHolidays=[];
                        for(var i=0;i<holidays.length;i++){
                            arrOfHolidays.push({'name':holidays[i].name,'description':holidays[i].description,'type':holidays[i].type.toString(),'date':holidays[i].date.iso});
                        }

                        this.holidayData=arrOfHolidays;
                     }
                }
                this.showLoadingSpinner = false;
                // showing success message

                 const event = new ShowToastEvent({
                    title: 'Success!!',
                    message: 'Successfully Updated',
                    variant: 'success',
                    mode: 'dismissable'
                });
                this.dispatchEvent(event);


            }).catch(error => {
                console.log("###error",error);
                this.showLoadingSpinner = false;
                    const event = new ShowToastEvent({
                    title: 'Error!!',
                    message:error.body.message,
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(event);
            });
    }
    handleChangeSouthAfricaId(event){
        this.isdisabledSearch=true;
        this.southAfricaId = event.detail.value;
        this.errMessage='A South African ID number is a 13-digit number which is defined by the following format: YYMMDDSSSSCAZ.';
      
        if(this.southAfricaId.length==13){
              this.southAfricaRecordDetails=this.verifySouthAfricaId(this.southAfricaId);
              if( this.southAfricaRecordDetails!=false && this.southAfricaRecordDetails.Valid){
                  this.isdisabledSearch=false;
                  this.errMessage='';
              }
        }
        console.log("###this.southAfricaRecordDetails",this.southAfricaRecordDetails);

    }
    verifySouthAfricaId(num) {
       
        //Equation to verify.
        if (isNaN(num) || num === '' || num.length !== 13 || num.substring(2,4) === '00' || num.substring(4,6) === '00') {
            return false;
        }
        let step1 = 0;
        let step2 = '';
        let step4 = 0;
        let i;
        for (i = 1; i < 14; i++) {
            if (i%2!==0 && i<=11 ){
                step1+=parseInt(num[i-1]);
            }
            else if (i<=12) {
                step2 += String(num[i - 1]);
            }
        }
        const step3 = String(parseInt(step2) * 2);
        let j;
        for (j = 0; j < step3.length; j++) {
            step4+=parseInt(step3[j]);
        }
        const step5 = String(step1+step4);
        const step6 = 10-parseInt(step5[step5.length-1]);
        
        //Gender & Citizenship
        const gender = (parseInt(num.substring(6, 10)) < 5000) ? "Female" : "Male";
        const citizenship = (parseInt(num.substring(10, 11)) === 0) ? "SA Citizen" : "Permanent Residence";

        //Date of Birth
        const tempDate = new Date(num.substring(0, 2), num.substring(2, 4) - 1, num.substring(4, 6));
        const id_month = tempDate.getMonth();
        const id_date = tempDate.getDate();
        //Condition for year (19xx or 20xx)
        const year = new Date().getFullYear();
        const year_first = String(year).substring(0, 2);
        const id_year_last = String(tempDate.getFullYear()).substring(2, 4);
        let prefix;
        if (tempDate <= year) {
            prefix = year_first;
        } else {
            prefix = String(parseInt(year_first) - 1);
        }
        const DoB = (id_month + 1) + "/" +  id_date+ "/" + prefix + id_year_last;

        //Valid: returns true
        return {Valid:num[num.length - 1] === String(step6),Gender:gender,Citizen:citizenship,BirthDate:DoB};
    }
    onlyNumericAllowed(event) {
         var key = event.keyCode;
         console.log("###key",key);
        // Only allow numbers to be entered

        if(key!=8 && key!=86){
            if (key < 48 || key > 57 )  {
                event.preventDefault();
            }
        }

    }
}